# المصادر الرسمية

تاريخ المراجعة 17 نوفمبر 2026

- [Microsoft Power Apps pricing](https://www.microsoft.com/en-us/power-platform/products/power-apps/pricing)
- [Power Apps price change January 2027](https://www.microsoft.com/en-us/licensing/news/power-apps-premium-price-update)
- [Power Automate pricing](https://www.microsoft.com/en-us/power-platform/products/power-automate/pricing)
- [Microsoft 365 Business Basic](https://www.microsoft.com/en-us/microsoft-365/business/microsoft-365-business-basic)
- [Licensing FAQ](https://learn.microsoft.com/en-us/power-platform/admin/powerapps-flow-licensing-faq)
- [Developer environments timeline](https://learn.microsoft.com/en-us/power-platform/important-changes-coming)
- [Solution distribution](https://learn.microsoft.com/en-us/power-apps/maker/model-driven-apps/distribute-model-driven-app)
- [Environment users](https://learn.microsoft.com/en-us/power-platform/admin/add-users-to-environment)
- [Security roles](https://learn.microsoft.com/en-us/power-platform/admin/create-edit-security-role)
- [Custom APIs](https://learn.microsoft.com/en-us/power-apps/developer/data-platform/create-custom-api-prt)
- [SharePoint versioning](https://support.microsoft.com/en-gb/sharepoint/lists/documents-and-library/enable-and-configure-versioning-for-a-list-or-library?tabs=modern)