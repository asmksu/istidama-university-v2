"""Prepare a separate, offline copy of the seven runtime web resources.
No login, secrets, HTTP requests, metadata edits, or data migration occur here.
"""
import argparse,json,re,uuid
from pathlib import Path

def prepare(root,config,output):
 root=Path(root).resolve();out=Path(output).resolve();cfg=json.loads(Path(config).read_text(encoding='utf-8-sig'))
 url=cfg['dataverse_url'].rstrip('/')
 if not re.fullmatch(r'https://[A-Za-z0-9.-]+',url):raise ValueError('dataverse_url must be an HTTPS origin without a path')
 old={'environment_id':'63ee0037-0213-e9ff-b232-fb0a8f2d6a42','solution_id':'49740c1a-b7d2-f111-a05a-6045bd87a893','app_id':'fe9299c6-bad2-f111-a05a-6045bd87a893','tenant_id':'19df06c3-3fcd-4947-809f-064684abf608'}
 substitutions={'https://org3948ba10.crm4.dynamics.com':url}
 for key,val in old.items():
  new=str(uuid.UUID(cfg[key]))
  if new==str(uuid.UUID(int=0)) or new==val:raise ValueError(key+' must contain the target environment identifier')
  substitutions[val]=new
 site=cfg.get('sharepoint_site','').rstrip('/')
 if not site.startswith('https://'):raise ValueError('sharepoint_site must be the approved target SharePoint HTTPS URL')
 substitutions['https://studentksuedu.sharepoint.com/sites/ISTIDAMADev']=site
 source=root/'source/webresources'
 if out==source or source in out.parents:raise ValueError('Choose an output directory outside source/webresources')
 out.mkdir(parents=True,exist_ok=True);report=[]
 for p in sorted(source.iterdir()):
  if p.suffix not in ['.html','.js','.css']:continue
  text=p.read_text(encoding='utf-8');changes={}
  for before,after in substitutions.items():
   changes[before]=text.lower().count(before.lower());text=re.sub(re.escape(before),lambda m:after,text,flags=re.I)
  (out/p.name).write_text(text,encoding='utf-8');report.append({'file':p.name,'replacements':changes})
 (out/'preparation-report.json').write_text(json.dumps({'offlineOnly':True,'target':url,'resources':report,'manualReview':['Reconnect flows and SharePoint','Create real users, teams, and settings','No data is moved','Import and independent-user UAT still required']},ensure_ascii=False,indent=2),encoding='utf-8')
 return report

if __name__=='__main__':
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('project',nargs='?',default='.');p.add_argument('--config',required=True);p.add_argument('--output',required=True);a=p.parse_args();r=prepare(a.project,a.config,a.output);print('Prepared '+str(len(r))+' runtime resources. Review preparation-report.json before upload.')
