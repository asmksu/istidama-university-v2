/* Participant names document collaboration; this control does not grant access. */
function createMemberPicker(host, people, initial=[], options={}) {
 const safe=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const key=name=>name.trim().replace(/\s+/g,' ').toLocaleLowerCase();
 const directory=people.map(p=>({...p,id:String(p.id),name:String(p.name)}));
 const selected=new Map();let excluded=String(options.excludeId||'');
 for(const entry of initial){const name=typeof entry==='string'?entry:entry.name;const person=directory.find(p=>key(p.name)===key(name));const item=person||{id:'manual-'+crypto.randomUUID(),name};if(key(name)&&item.id!==excluded)selected.set(key(name),item);}
 host.classList.add('member-picker');
 host.innerHTML='<label>بحث عن مشارك<input type="search" class="member-search" placeholder="ابحث بالاسم أو القسم"></label><p class="member-count" aria-live="polite"></p><div class="member-selected"></div><div class="member-options"></div>'+(options.allowManual?'<div class="member-manual"><label>إضافة مشارك بالاسم<input type="text" maxlength="100" class="member-name" placeholder="اسم المشارك من أي قسم"></label><button type="button" class="member-add">إضافة مشارك</button></div><small>الاسم المضاف يوثّق المشاركة؛ لا ينشئ حساباً أو يمنح وصولاً للمهمة.</small>':'')+'<p class="member-message" role="status"></p>';
 const search=host.querySelector('.member-search'),list=host.querySelector('.member-options'),chips=host.querySelector('.member-selected');
 function paint(){
  const term=key(search.value),available=directory.filter(p=>p.id!==excluded&&key(p.name+' '+(p.department||'')).includes(term));
  host.querySelector('.member-count').textContent=selected.size?'المشاركون المحددون: '+selected.size:'لم تضف مشاركين بعد — يمكنك اختيار أكثر من شخص من أي قسم.';
  chips.innerHTML=Array.from(selected.values()).map(p=>'<button type="button" class="member-chip" data-remove="'+safe(p.id)+'" aria-label="إزالة '+safe(p.name)+'">'+safe(p.name)+' ×</button>').join('');
  list.innerHTML=available.length?available.map(p=>'<label class="member-choice"><input type="checkbox" value="'+safe(p.id)+'" '+(selected.has(key(p.name))?'checked':'')+'><span>'+safe(p.name)+(p.department?'<small>'+safe(p.department)+'</small>':'')+'</span></label>').join(''):'<p class="member-empty">'+(term?'لا توجد أسماء مطابقة.':options.allowManual?'لا يوجد موظفون آخرون في الدليل حالياً؛ أضف المشاركين بالاسم أدناه.':'لا يوجد مشاركون متاحون.')+'</p>';
  list.querySelectorAll('input').forEach(input=>input.onchange=()=>{const person=directory.find(p=>p.id===input.value);if(input.checked)selected.set(key(person.name),person);else selected.delete(key(person.name));paint();});
  chips.querySelectorAll('button').forEach(button=>button.onclick=()=>{for(const [name,p]of selected)if(p.id===button.dataset.remove)selected.delete(name);paint();});
 }
 search.oninput=paint;
 search.onkeydown=e=>{if(e.key==='Enter')e.preventDefault();};
 if(options.allowManual){const input=host.querySelector('.member-name');const add=()=>{const name=input.value.trim().replace(/\s+/g,' '),message=host.querySelector('.member-message');message.textContent='';if(!name){message.textContent='اكتب اسم المشارك أولاً.';return;}const primary=directory.find(p=>p.id===excluded);if(primary&&key(primary.name)===key(name)){message.textContent='هذا الشخص هو المسؤول الرئيسي بالفعل.';return;}if(selected.has(key(name))){message.textContent='هذا المشارك مضاف بالفعل.';return;}selected.set(key(name),directory.find(p=>key(p.name)===key(name))||{id:'manual-'+crypto.randomUUID(),name});input.value='';paint();input.focus();};host.querySelector('.member-add').onclick=add;input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();add();}};}
 paint();
 return {values:()=>Array.from(selected.values()),setExcluded(id){excluded=String(id||'');const person=directory.find(p=>p.id===excluded);if(person)selected.delete(key(person.name));paint();}};
}
