/* Shared preference for the dashboard and training page; independent of task data. */
(()=>{
 const key='istidama-theme',root=document.documentElement,system=window.matchMedia('(prefers-color-scheme: dark)');
 const saved=()=>{try{return localStorage.getItem(key);}catch{return null;}};
 const preferred=()=>['dark','light'].includes(saved())?saved():(system.matches?'dark':'light');
 function apply(mode){root.dataset.istTheme=mode;root.style.colorScheme=mode;const button=document.getElementById('ist-theme-toggle');if(button){const dark=mode==='dark';button.textContent=dark?'☀️':'🌙';button.setAttribute('aria-label',dark?'التبديل إلى الوضع الفاتح':'التبديل إلى الوضع الداكن');button.setAttribute('aria-pressed',String(dark));button.title=dark?'التبديل إلى الوضع الفاتح':'التبديل إلى الوضع الداكن';}}
 apply(preferred());
 function install(){const header=document.querySelector('header');if(!header||document.getElementById('ist-theme-toggle'))return;const button=document.createElement('button');button.id='ist-theme-toggle';button.type='button';button.className='theme-toggle';button.onclick=()=>{const next=root.dataset.istTheme==='dark'?'light':'dark';try{localStorage.setItem(key,next);}catch{}apply(next);};const refresh=header.querySelector('#refresh')||header.querySelector('#reload');if(refresh){const group=document.createElement('div');group.className='header-actions';header.append(group);group.append(refresh,button);}else{const anchor=header.querySelector('h1');if(anchor)anchor.before(button);else header.append(button);}apply(root.dataset.istTheme);}
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
 window.addEventListener('storage',event=>{if(event.key===key)apply(preferred());});
 system.addEventListener('change',()=>{if(!['dark','light'].includes(saved()))apply(preferred());});
})();
