async function novPositiveReviewTest(){
 const who=(await api('GET','WhoAmI')).UserId,team=(await findDemo('ist_team',"ist_code eq 'DEMO-A1'"))[0],process=(await findDemo('ist_process',"statecode eq 0"))[0],set=await metaSet('ist_workitem'),ref='DEMO-NOV26-ACCEPTANCE';
 let w=(await findDemo('ist_workitem',"ist_externalref eq '"+ref+"'"))[0];
 if(w){note('NOV ACCEPTANCE ALREADY EXISTS; inspect immutable history rather than rerun it.');return;}
 await api('POST',set,{ist_name:'عرض — اختبار مسار الاعتماد والإعادة',ist_externalref:ref,ist_taskkind:1,ist_description:'سجل اختبار اصطناعي لمسار ثلاث مراحل وإعادة العمل.',ist_expectedhours:4,ist_requesterlevel:3,ist_startdate:'2026-11-15',ist_baseline:'2026-12-30',ist_due:'2026-12-30',ist_phase:100000001,ist_priority:100000001,ist_unplanned:true,ist_unplannedreason:'اختبار قبول للمسار الجديد فقط.',ist_approvallevel:3,'ist_team@odata.bind':'/'+await metaSet('ist_team')+'('+team.ist_teamid+')','ist_department@odata.bind':'/'+await metaSet('ist_department')+'('+team._ist_department_value+')','ist_process@odata.bind':'/'+await metaSet('ist_process')+'('+process.ist_processid+')','ist_executionowner@odata.bind':'/systemusers('+who+')','ist_planningowner@odata.bind':'/systemusers('+who+')'});
 w=(await findDemo('ist_workitem',"ist_externalref eq '"+ref+"'"))[0];const path=set+'('+w.ist_workitemid+')';let pass=0;
 const assert=async(title,status,stage,rev)=>{const x=await api('GET',path+'?$select=ist_approvalstatus,ist_approvalstage,ist_reviewrevision');if(x.ist_approvalstatus!==status||x.ist_approvalstage!==stage||x.ist_reviewrevision!==rev)throw Error('FAIL '+title+' '+JSON.stringify(x));pass++;note('PASS '+title);};
 const reject=async(title,expected,fn)=>{try{await fn();throw Error('UNEXPECTED SUCCESS '+title);}catch(e){if(!e.message.includes(expected))throw e;pass++;note('PASS '+title+' — '+e.message);}};
 const decide=(Decision,ExpectedRevision,Notes='اختبار قبول تجريبي')=>api('POST','ist_TaskReview',{WorkItemId:w.ist_workitemid,Decision,ExpectedRevision:String(ExpectedRevision),Notes});
 await reject('block direct approval','إجراء الاعتماد',()=>api('PATCH',path,{ist_approvalstatus:4}));
 await decide('submit',0);await assert('first stage pending',2,1,1);
 await reject('block completion before approval','جميع مراحل',()=>api('PATCH',path,{ist_phase:100000004}));
 await reject('mandatory rejection notes','ملاحظات الإعادة',()=>decide('reject',1,''));
 await decide('approve',1);await assert('department stage pending',2,2,2);
 await reject('block stale decision','تغير الطلب',()=>decide('approve',1));
 await reject('scope locked during review','تفاصيل المهمة',()=>api('PATCH',path,{ist_description:'تغيير غير معتمد أثناء المراجعة'}));
 await decide('approve',2);await assert('general manager pending',2,3,3);
 await decide('reject',3,'أكمل التوثيق ثم أعد الإرسال');await assert('rework retains rejected stage',3,3,4);
 await api('PATCH',path,{ist_description:'أكمل توثيق النطاق والإجراء التالي بعد الإعادة.'});
 await decide('submit',4);await assert('resubmission restarts at section',2,1,5);
 await decide('approve',5);await decide('approve',6);await decide('approve',7);await assert('final approval after all stages',4,3,8);
 note('NOV POSITIVE ACCEPTANCE '+pass+'/11; same setup account, not independent-person security test.');
}
novButton('5 اختبار دورة الاعتماد والإعادة كاملة',novPositiveReviewTest);
