# Somar Sans — Baianat

Publisher announcement: https://www.behance.net/gallery/113169369/Somar-Sans-Typeface
Official download: https://www.baianat.com/download/file-lo6pb8lrrvuiye

The publisher states: “Get Somar Sans for free to use in your commercial and personal projects.” The description explicitly covers websites and digital applications. The official archive supplies Web/Standard WOFF2 files; these are copied byte-for-byte, without subsetting or modifying the fonts. Nine weights (100–900), each normal and italic, are included. Copyright and original font metadata remain intact. No OFL claim is made; no separate license document was present in the publisher archive.
