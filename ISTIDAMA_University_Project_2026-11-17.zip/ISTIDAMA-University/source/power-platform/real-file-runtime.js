
async function linkRealDemoFile(){
 const one=async(n,f)=>(await api('GET',(await metaSet(n))+'?$filter='+f+'&$top=1')).value[0];
 const source=await one('ist_handover',"ist_name eq 'تجريبي — تسليم التقرير للفريق B1'");
 const work=await one('ist_workitem',"ist_externalref eq 'DEMO-GOV-UNAPPROVED'");
 const who=await api('GET','WhoAmI');if(!source||!work)throw Error('Run demo and governance tests first');
 const d=await ensure('ist_deliverable','ist_name','تجريبي — تقرير SharePoint الفعلي',{ist_name:'تجريبي — تقرير SharePoint الفعلي','ist_workitem@odata.bind':await bind('ist_workitem',work.ist_workitemid),ist_type:'تقرير دوري تجريبي',ist_due:'2026-11-01',ist_phase:100000001,'ist_producerteam@odata.bind':await bind('ist_team',source._ist_producerteam_value),'ist_approverteam@odata.bind':await bind('ist_team',source._ist_approverteam_value)});
 const v=await ensure('ist_documentversion','ist_name','تجريبي — ملف SharePoint 04',{ist_name:'تجريبي — ملف SharePoint 04','ist_deliverable@odata.bind':await bind('ist_deliverable',d),ist_number:4,ist_sharepointurl:'https://studentksuedu.sharepoint.com/sites/ISTIDAMADev/DocLib/IST_A_REPORT_20261028_v04.txt','ist_uploader@odata.bind':'/systemusers('+who.UserId+')',ist_uploadedat:new Date().toISOString(),ist_phase:100000000});
 const h=await ensure('ist_handover','ist_name','تجريبي — تسليم ملف SharePoint الفعلي',{ist_name:'تجريبي — تسليم ملف SharePoint الفعلي','ist_deliverable@odata.bind':await bind('ist_deliverable',d),'ist_workitem@odata.bind':await bind('ist_workitem',work.ist_workitemid),'ist_producerteam@odata.bind':await bind('ist_team',source._ist_producerteam_value),'ist_approverteam@odata.bind':await bind('ist_team',source._ist_approverteam_value),'ist_assignedapprover@odata.bind':'/systemusers('+who.UserId+')',ist_phase:100000001});
 note('REAL FILE METADATA LINKED; draft handover '+h+'; version '+v+'. No Teams request was sent.');
}
const realButton=document.createElement('button');realButton.id='realFile';realButton.textContent='ربط ملف SharePoint التجريبي المرفوع';document.getElementById('state').before(realButton);realButton.onclick=async()=>{realButton.disabled=true;try{await linkRealDemoFile();}catch(e){note('REAL FILE FAILED '+e.message);}finally{realButton.disabled=false;}};
