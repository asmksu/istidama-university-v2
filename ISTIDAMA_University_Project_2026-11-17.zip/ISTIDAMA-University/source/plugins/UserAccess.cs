using System;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;

namespace Istidama.Governance {
 internal static class AccessPolicy {
  internal const string Table="ist_appuser", Event="ist_useraccessevent", Api="ist_ManageUserAccess";
  internal static bool InApi(IPluginExecutionContext c){for(var p=c;p!=null;p=p.ParentContext)if(p.MessageName==Api)return true;return false;}
  internal static bool SystemAdmin(IOrganizationService s,Guid user){
   foreach(bool inherited in new[]{false,true}){var q=new QueryExpression("role"){ColumnSet=new ColumnSet(false),TopCount=1};var names=new FilterExpression(LogicalOperator.Or);names.AddCondition("name",ConditionOperator.Equal,"System Administrator");names.AddCondition("name",ConditionOperator.Equal,"مسؤول النظام");q.Criteria.AddFilter(names);
    if(inherited){var roles=q.AddLink("teamroles","roleid","roleid");var members=roles.AddLink("teammembership","teamid","teamid");members.LinkCriteria.AddCondition("systemuserid",ConditionOperator.Equal,user);}else{var roles=q.AddLink("systemuserroles","roleid","roleid");roles.LinkCriteria.AddCondition("systemuserid",ConditionOperator.Equal,user);}if(s.RetrieveMultiple(q).Entities.Count>0)return true;
   }return false;
  }
  internal static bool Admin(IOrganizationService s,Guid user){if(SystemAdmin(s,user))return true;var q=new QueryExpression(Table){ColumnSet=new ColumnSet(false),TopCount=1};q.Criteria.AddCondition("ist_systemuser",ConditionOperator.Equal,user);q.Criteria.AddCondition("ist_status",ConditionOperator.Equal,1);q.Criteria.AddCondition("ist_role",ConditionOperator.Equal,5);return s.RetrieveMultiple(q).Entities.Count>0;}
  internal static void RequireAdmin(IOrganizationService s,Guid user){if(!Admin(s,user))Guard.Fail("إدارة المستخدمين والصلاحيات لمسؤولي استدامة المفعلين فقط.");}
  internal static string RoleName(int role){return role==5?"ISTIDAMA - مسؤول استدامة":role==0?"ISTIDAMA - موظف":role<3?"ISTIDAMA - قائد الفريق":"ISTIDAMA - مدير الإدارة";}
  internal static string RoleLabel(int role){return new[]{"موظف","مدير التخطيط","مدير المراقبة","مدير الإدارة","المدير العام","مسؤول النظام — استدامة"}[role];}
  internal static string ManagerField(int role){return role==1?"ist_planningapprover":role==2?"ist_monitoringapprover":role==3?"ist_departmentapprover":role==4?"ist_generalapprover":null;}
  internal static EntityReference ManagedRole(Entity e){Guid id;return Guid.TryParse(Guard.Text(e,"ist_managedrole"),out id)?new EntityReference("role",id):null;}
 }
 public sealed class UserDirectoryGuard:IPlugin {
  public void Execute(IServiceProvider p){var c=(IPluginExecutionContext)p.GetService(typeof(IPluginExecutionContext));var s=((IOrganizationServiceFactory)p.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(c.InitiatingUserId);var privileged=((IOrganizationServiceFactory)p.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(null);AccessPolicy.RequireAdmin(privileged,c.InitiatingUserId);
   if(c.PrimaryEntityName==AccessPolicy.Event){if(c.MessageName!="Create"||!AccessPolicy.InApi(c))Guard.Fail("سجل الصلاحيات ثابت ويحفظه إجراء إدارة المستخدمين فقط.");return;}
   if(c.MessageName=="Delete")Guard.Fail("الحذف من قائمة استدامة يتم عبر إجراء إدارة المستخدمين مع حفظ السجل وإمكانية الاستعادة.");
   var t=c.InputParameters["Target"] as Entity;if(t==null)return;bool create=c.MessageName=="Create",inside=AccessPolicy.InApi(c);var e=create?new Entity(AccessPolicy.Table):s.Retrieve(AccessPolicy.Table,t.Id,new ColumnSet(true));int prior=Guard.Int(e,"ist_status");foreach(var a in t.Attributes)e[a.Key]=a.Value;
   var protectedFields=new[]{"ist_status","ist_revision","ist_systemuser","ist_managedrole","ist_managedteam","ist_addedrole","ist_addedmembership","ist_previousapprovers","ist_activatedat"};
   if(!inside&&protectedFields.Any(t.Contains))Guard.Fail("حالة التفعيل والصلاحيات يحفظها إجراء إدارة المستخدمين فقط.");
   if(!inside&&!create&&prior==3)Guard.Fail("استعد المستخدم المحذوف قبل تعديل بياناته.");
   if(!inside&&!create&&prior==1)Guard.Fail("أوقف الصلاحيات أولاً قبل تغيير البريد أو الدور أو الفريق.");
   string name=(Guard.Text(e,"ist_name")??"").Trim(),email=(Guard.Text(e,"ist_email")??"").Trim().ToLowerInvariant();int role=Guard.Int(e,"ist_role");
   if(name.Length==0||name.Length>200)Guard.Fail("اسم المستخدم إلزامي وبحد أقصى 200 حرف.");
   if(email.Length>254||!Regex.IsMatch(email,@"^[^\s@]+@[^\s@]+\.[^\s@]+$"))Guard.Fail("أدخل بريداً إلكترونياً صحيحاً.");
   if(role<0||role>5)Guard.Fail("الدور غير صالح.");if(role<3&&Guard.Ref(e,"ist_team")==null)Guard.Fail("اختر الفريق للموظف أو مدير القسم.");
   var q=new QueryExpression(AccessPolicy.Table){ColumnSet=new ColumnSet(false),TopCount=1};q.Criteria.AddCondition("ist_email",ConditionOperator.Equal,email);if(!create)q.Criteria.AddCondition(AccessPolicy.Table+"id",ConditionOperator.NotEqual,t.Id);if(s.RetrieveMultiple(q).Entities.Count>0)Guard.Fail("هذا البريد مسجل بالفعل في قائمة المستخدمين.");
   t["ist_name"]=name;t["ist_email"]=email;if(create){t["ist_status"]=0;t["ist_revision"]=0;}else if(!inside)t["ist_revision"]=Guard.Int(e,"ist_revision")+1;
  }
 }
 public sealed class ManageUserAccess:IPlugin {
  public void Execute(IServiceProvider p){var c=(IPluginExecutionContext)p.GetService(typeof(IPluginExecutionContext));var s=((IOrganizationServiceFactory)p.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(c.InitiatingUserId);var privileged=((IOrganizationServiceFactory)p.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(null);AccessPolicy.RequireAdmin(privileged,c.InitiatingUserId);
   Guid id=Ops.Id(c,"AppUserId");var record=s.Retrieve(AccessPolicy.Table,id,new ColumnSet(true));int expected;if(!Int32.TryParse(Convert.ToString(c.InputParameters["ExpectedRevision"]),out expected)||expected!=Guard.Int(record,"ist_revision"))Guard.Fail("تغير سجل المستخدم؛ حدّث القائمة قبل المتابعة.");
   string action=Convert.ToString(c.InputParameters["Action"]);if(!new[]{"activate","deactivate","delete","restore"}.Contains(action))Guard.Fail("إجراء غير صالح.");int status=Guard.Int(record,"ist_status");
   if(status==3&&action!="restore")Guard.Fail("المستخدم محذوف من القائمة؛ استعده أولاً.");if(action=="restore"&&status!=3)Guard.Fail("الاستعادة للمستخدم المحذوف فقط.");
   if(action=="delete"){var linked=Guard.Ref(record,"ist_systemuser");if(linked!=null&&linked.Id==c.InitiatingUserId)Guard.Fail("لا تحذف حسابك الحالي من قائمة استدامة؛ اطلب من مسؤول آخر.");if(linked!=null&&AccessPolicy.SystemAdmin(privileged,linked.Id))Guard.Fail("حساب مسؤول النظام لا يحذف من هذه القائمة.");}
   if(action=="activate"&&status==1){c.OutputParameters["Result"]="صلاحيات استدامة مفعلة بالفعل.";return;}if(action=="deactivate"&&status!=1)Guard.Fail("هذا المستخدم غير مفعل حالياً.");
   if(String.IsNullOrEmpty(record.RowVersion))Guard.Fail("تعذر قراءة إصدار السجل؛ لم تتغير الصلاحيات.");var locked=new Entity(AccessPolicy.Table,id){RowVersion=record.RowVersion};locked["ist_revision"]=expected+1;s.Execute(new UpdateRequest{Target=locked,ConcurrencyBehavior=ConcurrencyBehavior.IfRowVersionMatches});
   var update=new Entity(AccessPolicy.Table,id);string details;
   if(action=="restore"){
    update["ist_status"]=Guard.Ref(record,"ist_systemuser")==null?0:2;details="استعادة المستخدم إلى قائمة استدامة دون تفعيل صلاحياته؛ الربط والتفعيل إجراء مستقل.";
   }else if(action=="delete"&&status!=1){
    update["ist_status"]=3;details="سجل الصلاحيات والمهام وحساب Microsoft محفوظة؛ لا صلاحيات مفعلة من هذه القائمة لإيقافها.";
   }else if(action=="activate"){
    int role=Guard.Int(record,"ist_role");string email=Guard.Text(record,"ist_email");var query=new QueryExpression("systemuser"){ColumnSet=new ColumnSet("fullname","businessunitid","isdisabled","accessmode"),TopCount=2};query.Criteria.AddCondition("isdisabled",ConditionOperator.Equal,false);query.Criteria.AddCondition("accessmode",ConditionOperator.Equal,0);var match=new FilterExpression(LogicalOperator.Or);match.AddCondition("internalemailaddress",ConditionOperator.Equal,email);match.AddCondition("domainname",ConditionOperator.Equal,email);query.Criteria.AddFilter(match);var users=s.RetrieveMultiple(query).Entities;
    if(users.Count!=1)Guard.Fail("لم يعثر على حساب Microsoft نشط واحد بهذا البريد داخل البيئة. يجب إضافته إلى البيئة وتوفير الترخيص المناسب أولاً؛ حفظ البريد وحده لا ينشئ حساباً.");var user=users[0];if(AccessPolicy.SystemAdmin(privileged,user.Id))Guard.Fail("حساب مسؤول النظام لا تدار صلاحياته من هذه القائمة.");
    var duplicate=new QueryExpression(AccessPolicy.Table){ColumnSet=new ColumnSet(false),TopCount=1};duplicate.Criteria.AddCondition("ist_systemuser",ConditionOperator.Equal,user.Id);duplicate.Criteria.AddCondition("ist_status",ConditionOperator.Equal,1);duplicate.Criteria.AddCondition(AccessPolicy.Table+"id",ConditionOperator.NotEqual,id);if(s.RetrieveMultiple(duplicate).Entities.Count>0)Guard.Fail("هذا الحساب مرتبط بسجل مفعل آخر؛ أوقفه قبل تغييره.");
    if(role>0&&role<5){var occupied=new QueryExpression(AccessPolicy.Table){ColumnSet=new ColumnSet(false),TopCount=1};occupied.Criteria.AddCondition("ist_role",ConditionOperator.Equal,role);occupied.Criteria.AddCondition("ist_status",ConditionOperator.Equal,1);if(role<3)occupied.Criteria.AddCondition("ist_team",ConditionOperator.Equal,Guard.Ref(record,"ist_team").Id);if(s.RetrieveMultiple(occupied).Entities.Count>0)Guard.Fail("يوجد مستخدم مفعل لهذا المنصب؛ أوقفه أولاً قبل تعيين البديل.");}
    var roles=new QueryExpression("role"){ColumnSet=new ColumnSet(false),TopCount=1};roles.Criteria.AddCondition("name",ConditionOperator.Equal,AccessPolicy.RoleName(role));roles.Criteria.AddCondition("businessunitid",ConditionOperator.Equal,Guard.Ref(user,"businessunitid").Id);var native=s.RetrieveMultiple(roles).Entities.FirstOrDefault();if(native==null)Guard.Fail("دور استدامة غير مجهز في وحدة أعمال هذا الحساب؛ راجع مسؤول البيئة.");
    var existing=new QueryExpression("role"){ColumnSet=new ColumnSet(false),TopCount=1};existing.Criteria.AddCondition("roleid",ConditionOperator.Equal,native.Id);existing.AddLink("systemuserroles","roleid","roleid").LinkCriteria.AddCondition("systemuserid",ConditionOperator.Equal,user.Id);bool addedRole=s.RetrieveMultiple(existing).Entities.Count==0;
    if(addedRole)privileged.Associate("systemuser",user.Id,new Relationship("systemuserroles_association"),new EntityReferenceCollection{native.ToEntityReference()});
    bool addedMembership=false;var functional=Guard.Ref(record,"ist_team");EntityReference nativeTeam=null;if(role<3){var team=s.Retrieve("ist_team",functional.Id,new ColumnSet("ist_ownerteam","statecode"));if(Guard.Choice(team,"statecode")!=0)Guard.Fail("الفريق غير نشط.");nativeTeam=Guard.Ref(team,"ist_ownerteam");if(nativeTeam==null)Guard.Fail("الفريق الوظيفي بلا Owner Team.");addedMembership=!Guard.TeamMember(s,nativeTeam.Id,user.Id);if(addedMembership)privileged.Execute(new AddMembersTeamRequest{TeamId=nativeTeam.Id,MemberIds=new[]{user.Id}});}
    var previous=new StringBuilder();string field=AccessPolicy.ManagerField(role);if(field!=null){var teamQuery=new QueryExpression("ist_team"){ColumnSet=new ColumnSet(field)};teamQuery.Criteria.AddCondition("statecode",ConditionOperator.Equal,0);if(role<3)teamQuery.Criteria.AddCondition("ist_teamid",ConditionOperator.Equal,functional.Id);foreach(var team in s.RetrieveMultiple(teamQuery).Entities){var prior=Guard.Ref(team,field);previous.Append(team.Id).Append('|').Append(field).Append('|').Append(prior==null?"":prior.Id.ToString()).Append('\n');privileged.Update(new Entity("ist_team",team.Id){[field]=user.ToEntityReference()});}}
    update["ist_systemuser"]=user.ToEntityReference();update["ist_managedrole"]=native.Id.ToString();update["ist_managedteam"]=nativeTeam;update["ist_addedrole"]=addedRole?1:0;update["ist_addedmembership"]=addedMembership?1:0;update["ist_previousapprovers"]=previous.ToString();update["ist_status"]=1;update["ist_activatedat"]=DateTime.UtcNow;details="تفعيل "+AccessPolicy.RoleLabel(role)+" للحساب المرتبط. الأدوار السابقة غير الممنوحة من هذه القائمة تبقى كما هي. تعيين المعتمد يطبق على المهام الجديدة؛ الطلبات المرسلة تبقى للمعتمد المسجل فيها.";
   }else{
    EntityReference user=Guard.Ref(record,"ist_systemuser"),role=AccessPolicy.ManagedRole(record),team=Guard.Ref(record,"ist_managedteam");if(user==null)Guard.Fail("السجل المفعل بلا حساب مرتبط.");if(user.Id==c.InitiatingUserId)Guard.Fail("لا توقف صلاحيات حسابك الحالي من هذه القائمة؛ اطلب من مسؤول استدامة آخر تنفيذ التغيير.");if(AccessPolicy.SystemAdmin(privileged,user.Id))Guard.Fail("حساب مسؤول النظام لا يوقف من هذه القائمة.");
    foreach(string line in (Guard.Text(record,"ist_previousapprovers")??"").Split(new[]{'\n'},StringSplitOptions.RemoveEmptyEntries)){var parts=line.Split('|');Guid teamId=Guid.Empty,prior;if(parts.Length!=3||!Guid.TryParse(parts[0],out teamId)||!TaskRoute.Fields.Contains(parts[1]))Guard.Fail("سجل المعتمد السابق غير صالح؛ لم تتغير الصلاحيات.");var ft=s.Retrieve("ist_team",teamId,new ColumnSet(parts[1]));if(Guard.Same(Guard.Ref(ft,parts[1]),user))privileged.Update(new Entity("ist_team",teamId){[parts[1]]=Guid.TryParse(parts[2],out prior)?new EntityReference("systemuser",prior):null});}
    if((Guard.Int(record,"ist_addedmembership")==1)&&team!=null&&Guard.TeamMember(s,team.Id,user.Id))privileged.Execute(new RemoveMembersTeamRequest{TeamId=team.Id,MemberIds=new[]{user.Id}});
    if((Guard.Int(record,"ist_addedrole")==1)&&role!=null)privileged.Disassociate("systemuser",user.Id,new Relationship("systemuserroles_association"),new EntityReferenceCollection{role});update["ist_status"]=2;update["ist_addedrole"]=0;update["ist_addedmembership"]=0;details="إيقاف الصلاحيات والعضويات التي منحتها هذه القائمة فقط؛ حساب Microsoft والصلاحيات الأخرى لا تحذف.";
   }
   if(action=="delete"){update["ist_status"]=3;details="حذف المستخدم من قائمة استدامة مع إمكانية الاستعادة. "+details;}
   s.Update(update);s.Create(new Entity(AccessPolicy.Event){["ist_name"]=action=="delete"?"حذف مستخدم من استدامة":action=="restore"?"استعادة مستخدم استدامة":action=="activate"?"تفعيل صلاحيات استدامة":"إيقاف صلاحيات استدامة",["ist_appuser"]=record.ToEntityReference(),["ist_actor"]=new EntityReference("systemuser",c.InitiatingUserId),["ist_at"]=DateTime.UtcNow,["ist_details"]=details});c.OutputParameters["Result"]=details;
  }
 }
}
