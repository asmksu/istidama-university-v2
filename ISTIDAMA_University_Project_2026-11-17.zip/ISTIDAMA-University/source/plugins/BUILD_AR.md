# بناء قواعد الخادم

للنقل المطابق استعمل DLL المرفق الموقّع أو استورد الحل الأصلي. المصدر يضم Governance وActions وInitiatives وTaskReviews وUserAccess.

لتعديل القواعد استعمل Visual Studio وSDK معتمدين و.NET Framework 4.6.2 targeting pack وحزمة Microsoft.CrmSdk.CoreAssemblies المثبتة في csproj. المرجع الرسمي: https://www.nuget.org/packages/Microsoft.CrmSdk.CoreAssemblies/9.0.2.59

أنشئ مفتاح توقيع جديداً في مكان آمن خارج المستودع. شغّل من المجلد:

    dotnet build -c Release -p:SigningKeyFile=C:\Secure\ISTIDAMA.Work.snk

المفتاح الخاص القديم غير مرفق. المفتاح الجديد يغير PublicKeyToken وقد يحتاج تسجيل Assembly جديداً وإعادة ربط Plugin Types وCustom APIs وSDK Steps؛ لا تفترض أن الاستبدال المباشر سيقبل هوية مختلفة. راجع نوع framework المدعوم حالياً في جهة العمل قبل بناء نسخة معدلة.

ملف المشروع قالب بناء للبيئة الهدف، لم ينفذ فيه restore وبناء بمفتاح جديد خلال هذا التسليم. الملف الثنائي المرفق هو نفسه المصدر المنشور 1.0.0.15 وفحصت بصمته مع التصدير.
