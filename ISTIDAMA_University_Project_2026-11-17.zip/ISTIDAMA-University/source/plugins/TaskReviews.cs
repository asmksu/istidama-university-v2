using System;
using System.Linq;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;

namespace Istidama.Governance {
 internal static class TaskRoute {
  internal static readonly string[] Fields={"ist_sectionapprover","ist_planningapprover","ist_monitoringapprover","ist_departmentapprover","ist_generalapprover"};
  internal static string Field(string role){switch(role){case "P":return Fields[1];case "M":return Fields[2];case "D":return Fields[3];case "G":return Fields[4];default:return Fields[0];}}
  internal static string Label(string role){switch(role){case "P":return "مدير التخطيط";case "M":return "مدير المراقبة";case "D":return "مدير الإدارة";case "G":return "المدير العام";default:return "مدير القسم";}}
  internal static int LegacyLevel(string role){return role=="G"?3:role=="D"?2:1;}
  internal static string[] Path(Entity e){
   if(e.Contains("ist_approvalpath")&&e["ist_approvalpath"]!=null){var text=Guard.Text(e,"ist_approvalpath");if(String.IsNullOrWhiteSpace(text))return new string[0];var path=text.Split(',').Select(x=>x.Trim().ToUpperInvariant()).ToArray();if(path.Length>4||path.Distinct().Count()!=path.Length||path.Any(x=>!new[]{"P","M","D","G"}.Contains(x)))Guard.Fail("اختر معتمدين مختلفين من التخطيط والمراقبة والإدارة والعام بحد أقصى أربع خطوات.");return path;}
   return TaskPolicy.Levels(e).Select(x=>new[]{"","S","D","G"}[x]).ToArray();
  }
  internal static int Position(Entity e,string[] path){if(!String.IsNullOrWhiteSpace(Guard.Text(e,"ist_approvalpath")))return Guard.Int(e,"ist_reviewposition");int stage=Guard.Int(e,"ist_approvalstage");return stage<1||stage>3?0:Array.IndexOf(path,new[]{"","S","D","G"}[stage])+1;}
  internal static void SetPosition(Entity update,string[] path,int position){update["ist_reviewposition"]=position;update["ist_approvalstage"]=position==0?0:LegacyLevel(path[position-1]);}
 }
 public sealed class TaskPolicy : IPlugin {
  internal static readonly string[] Protected={"ist_approvalstatus","ist_approvalstage","ist_reviewposition","ist_reviewrevision","ist_submittedat","ist_approvedat"};
  internal static readonly string[] Route={"ist_approvallevel","ist_approvalroute","ist_approvalpath","ist_sectionapprover","ist_planningapprover","ist_monitoringapprover","ist_departmentapprover","ist_generalapprover","ist_team"};
  internal static readonly string[] Approvers={"ist_sectionapprover","ist_departmentapprover","ist_generalapprover"};
  internal static int[] Levels(Entity e){int mask=e.Contains("ist_approvalroute")&&e["ist_approvalroute"]!=null?Guard.Int(e,"ist_approvalroute"):(1<<Guard.Int(e,"ist_approvallevel"))-1;if(mask<0||mask>7)Guard.Fail("مسار الاعتماد غير صالح.");return Enumerable.Range(1,3).Where(i=>(mask&(1<<(i-1)))!=0).ToArray();}
  internal static bool InReview(IPluginExecutionContext c){for(var p=c;p!=null;p=p.ParentContext)if(p.MessageName=="ist_TaskReview")return true;return false;}
  public void Execute(IServiceProvider p){
   var c=(IPluginExecutionContext)p.GetService(typeof(IPluginExecutionContext));
   var target=c.InputParameters.Contains("Target")?c.InputParameters["Target"] as Entity:null;if(target==null)return;
   var s=((IOrganizationServiceFactory)p.GetService(typeof(IOrganizationServiceFactory))).CreateOrganizationService(null);
   bool create=c.MessageName=="Create",review=InReview(c);var old=create?new Entity("ist_workitem"):s.Retrieve("ist_workitem",target.Id,new ColumnSet(true));
   var e=new Entity("ist_workitem",target.Id);foreach(var a in old.Attributes)e[a.Key]=a.Value;foreach(var a in target.Attributes)e[a.Key]=a.Value;
   var path=TaskRoute.Path(e);int level=path.Length==0?0:TaskRoute.LegacyLevel(path.Last()),status=Guard.Int(e,"ist_approvalstatus");
   if(create||target.Contains("ist_executionowner")){var assigned=Guard.Ref(e,"ist_executionowner");if(assigned!=null){var person=s.Retrieve("systemuser",assigned.Id,new ColumnSet("isdisabled","accessmode"));if(person.GetAttributeValue<bool>("isdisabled")||Guard.Choice(person,"accessmode")!=0)Guard.Fail("اختر موظفاً نشطاً بحساب مستخدم تفاعلي.");}}
   if(e.Contains("ist_taskkind")&&(Guard.Int(e,"ist_taskkind")<0||Guard.Int(e,"ist_taskkind")>2))Guard.Fail("نوع المهمة غير صالح.");
   if(Guard.Number(e,"ist_expectedhours")<0)Guard.Fail("الوقت المتوقع لا يكون سالباً.");
   if(!create&&target.Contains("ist_requestedby"))Guard.Fail("رافع المهمة ثابت ويحفظه الخادم.");
   if(!review&&Protected.Any(k=>target.Contains(k)))Guard.Fail("مرحلة الاعتماد ونتيجته تحفظان من إجراء الاعتماد فقط.");
   if(create){target["ist_requestedby"]=new EntityReference("systemuser",c.InitiatingUserId);target["ist_approvalstage"]=0;target["ist_reviewposition"]=0;target["ist_reviewrevision"]=0;target["ist_approvalstatus"]=level>0?1:0;}
   bool routeChanged=create||Route.Any(k=>target.Contains(k));
   if(!review&&routeChanged){
    if(!create&&(status==2||status==4))Guard.Fail("لا تعدل مسار طلب مرسل أو معتمد؛ أعده للمراجعة أولاً.");
    if(!create&&!Guard.Manager(s,c.InitiatingUserId))Guard.Fail("تعديل مسار الاعتماد بعد الإنشاء لمدير الإدارة فقط.");
    var tr=Guard.Ref(e,"ist_team");if(tr!=null){var team=s.Retrieve("ist_team",tr.Id,new ColumnSet(TaskRoute.Fields));foreach(string field in TaskRoute.Fields)target[field]=Guard.Ref(team,field);foreach(string role in path){var configured=Guard.Ref(team,TaskRoute.Field(role));if(configured==null)Guard.Fail("لم يضبط معتمد "+TaskRoute.Label(role)+". يضبطه المسؤول قبل الإرسال.");if(s.Retrieve("systemuser",configured.Id,new ColumnSet("isdisabled")).GetAttributeValue<bool>("isdisabled"))Guard.Fail("المعتمد غير نشط.");}}
    if(e.Contains("ist_approvalpath"))target["ist_approvalpath"]=String.Join(",",path);target["ist_approvalstatus"]=level>0?1:0;target["ist_approvallevel"]=level;if(!create)target["ist_reviewrevision"]=Guard.Int(old,"ist_reviewrevision")+1;
   }
   if(!review&&!create&&(status==2||status==4)&&new[]{"ist_name","ist_description","ist_expectedhours","ist_indicator","ist_planitem","ist_due","ist_executionowner","ist_requesterlevel"}.Any(k=>target.Contains(k)&&!Object.Equals(target[k],old.Contains(k)?old[k]:null)))Guard.Fail("تفاصيل المهمة قيد الاعتماد أو معتمدة؛ أعدها للتعديل قبل تغيير النطاق أو الموعد.");
   if(Guard.Choice(e,"ist_phase")==100000004&&level>0&&status!=4)Guard.Fail("لا تغلق المهمة قبل اكتمال جميع مراحل اعتمادها.");
  }
 }
 public sealed class TaskReview : IPlugin {
  public void Execute(IServiceProvider p){
   var c=(IPluginExecutionContext)p.GetService(typeof(IPluginExecutionContext));var factory=(IOrganizationServiceFactory)p.GetService(typeof(IOrganizationServiceFactory));
   var caller=factory.CreateOrganizationService(c.InitiatingUserId);Guid id=Ops.Id(c,"WorkItemId");caller.Retrieve("ist_workitem",id,new ColumnSet(false));
   var s=caller;var w=s.Retrieve("ist_workitem",id,new ColumnSet(true));
   int revision=Guard.Int(w,"ist_reviewrevision"),expected; if(!Int32.TryParse(Convert.ToString(c.InputParameters["ExpectedRevision"]),out expected)||revision!=expected)Guard.Fail("تغير الطلب منذ فتحه. حدّث الصفحة قبل اتخاذ القرار.");
   string decision=Convert.ToString(c.InputParameters["Decision"]),notes=c.InputParameters.Contains("Notes")?Convert.ToString(c.InputParameters["Notes"]):"";int status=Guard.Int(w,"ist_approvalstatus"),stage=Guard.Int(w,"ist_approvalstage"),level=Guard.Int(w,"ist_approvallevel");
   var path=TaskRoute.Path(w);int position=TaskRoute.Position(w,path);if(path.Length==0)Guard.Fail("المهمة لا تتطلب اعتماداً.");
   var u=new Entity("ist_workitem",id){RowVersion=w.RowVersion};u["ist_reviewrevision"]=revision+1;string title,next;
   if(decision=="submit"){
    if(status!=1&&status!=3)Guard.Fail("لا يمكن الإرسال من هذه الحالة.");
    bool assigned=Guard.Same(Guard.Ref(w,"ist_executionowner"),new EntityReference("systemuser",c.InitiatingUserId));
    bool requester=Guard.Same(Guard.Ref(w,"ist_requestedby"),new EntityReference("systemuser",c.InitiatingUserId));
    if(!assigned&&!requester&&!Guard.Manager(s,c.InitiatingUserId))Guard.Fail("الإرسال للمسؤول عن المهمة أو رافعها أو مدير الإدارة فقط.");
    foreach(string role in path){var a=Guard.Ref(w,TaskRoute.Field(role));if(a==null||s.Retrieve("systemuser",a.Id,new ColumnSet("isdisabled")).GetAttributeValue<bool>("isdisabled"))Guard.Fail("أكمل المعتمدين النشطين قبل الإرسال.");}
    TaskRoute.SetPosition(u,path,1);u["ist_approvalstatus"]=2;u["ist_submittedat"]=DateTime.UtcNow;title="إرسال المهمة للاعتماد";next="بانتظار "+TaskRoute.Label(path[0]);
   }else if(decision=="approve"||decision=="reject"||decision=="comment"){
    if(status!=2||position<1||position>path.Length)Guard.Fail("المهمة ليست معلقة في مرحلة اعتماد صحيحة.");
    var a=Guard.Ref(w,TaskRoute.Field(path[position-1]));if(a==null||a.Id!=c.InitiatingUserId)Guard.Fail("القرار للمعتمد المعين في المرحلة الحالية فقط.");
    if(decision=="comment"){
     if(String.IsNullOrWhiteSpace(notes))Guard.Fail("اكتب ملاحظات المدير قبل إرسالها.");title="ملاحظات "+TaskRoute.Label(path[position-1])+" — الخطوة "+position;next="حُفظت الملاحظات للمتابعة؛ يبقى الطلب بانتظار "+TaskRoute.Label(path[position-1]);
    }else if(decision=="reject"){
     if(String.IsNullOrWhiteSpace(notes))Guard.Fail("ملاحظات الإعادة إلزامية.");u["ist_approvalstatus"]=3;title="إعادة من "+TaskRoute.Label(path[position-1])+" — الخطوة "+position;next="تعديل المهمة ثم إعادة الإرسال من أول معتمد في المسار المختار";
    }else{title="اعتماد "+TaskRoute.Label(path[position-1])+" — الخطوة "+position;if(position<path.Length){TaskRoute.SetPosition(u,path,position+1);next="بانتظار "+TaskRoute.Label(path[position]);}else{u["ist_approvalstatus"]=4;u["ist_approvedat"]=DateTime.UtcNow;next="اكتملت الاعتمادات المختارة؛ الإغلاق يخضع أيضاً لاعتماد المخرجات";}}
   }else if(decision=="recall"){
    if(status!=2&&status!=4)Guard.Fail("الإعادة للتعديل متاحة للطلب المرسل أو المعتمد فقط.");
    if(!Guard.Manager(s,c.InitiatingUserId)&&!Guard.Same(Guard.Ref(w,"ist_requestedby"),new EntityReference("systemuser",c.InitiatingUserId)))Guard.Fail("سحب الطلب لرافعه أو مدير الإدارة فقط.");
    if(String.IsNullOrWhiteSpace(notes))Guard.Fail("سبب سحب الطلب إلزامي.");if(Guard.Choice(w,"ist_phase")==100000004)Guard.Fail("لا تسحب مهمة مغلقة.");u["ist_approvalstatus"]=3;TaskRoute.SetPosition(u,path,0);u["ist_approvedat"]=null;title="سحب المهمة للتعديل";next="إعادة الإرسال تبدأ من أول معتمد في المسار المختار";
   }else{Guard.Fail("قرار غير معروف.");return;}
   if(String.IsNullOrEmpty(w.RowVersion))Guard.Fail("تعذر قراءة إصدار السجل؛ لم يحفظ القرار.");
   s.Execute(new UpdateRequest{Target=u,ConcurrencyBehavior=ConcurrencyBehavior.IfRowVersionMatches});
   s.Create(new Entity("ist_workupdate"){["ist_name"]=title,["ist_workitem"]=w.ToEntityReference(),["ist_summary"]=title+(String.IsNullOrWhiteSpace(notes)?"":" — "+notes),["ist_nextaction"]=next});
   c.OutputParameters["Result"]=next;
  }
 }
 public sealed class TaskImpact : IPlugin {
  public void Execute(IServiceProvider p){var c=(IPluginExecutionContext)p.GetService(typeof(IPluginExecutionContext));var t=c.InputParameters["Target"] as Entity;if(t==null||!t.Contains("ist_indicator")||Guard.Ref(t,"ist_indicator")==null)return;var s=Ops.Service(p);var ind=s.Retrieve("ist_indicator",Guard.Ref(t,"ist_indicator").Id,new ColumnSet("ist_team","ist_unit"));
   var q=new QueryExpression("ist_impactlink"){ColumnSet=new ColumnSet(false),TopCount=1};q.Criteria.AddCondition("ist_workitem",ConditionOperator.Equal,t.Id);q.Criteria.AddCondition("ist_indicator",ConditionOperator.Equal,ind.Id);if(s.RetrieveMultiple(q).Entities.Count>0)return;
   s.Create(new Entity("ist_impactlink"){["ist_name"]="ارتباط المهمة بمؤشر الأداء",["ist_workitem"]=t.ToEntityReference(),["ist_indicator"]=ind.ToEntityReference(),["ist_type"]=new OptionSetValue(100000001),["ist_expected"]=0m,["ist_unit"]=Guard.Text(ind,"ist_unit")??"حسب تعريف المؤشر",["ist_indicatorteam"]=Guard.Ref(ind,"ist_team"),["ist_evidence"]="ارتباط سياقي بالمهمة؛ الأثر المتوقع الكمي لم يقدّر بعد."});
  }
 }
}
